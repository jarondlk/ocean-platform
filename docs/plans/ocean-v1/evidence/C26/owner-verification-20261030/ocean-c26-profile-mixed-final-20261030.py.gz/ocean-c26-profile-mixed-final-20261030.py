from pathlib import Path
from tempfile import TemporaryDirectory
import cProfile, pstats, hashlib, json, os, sys, time, uuid
ROOT=Path('/Users/jaronchai/Documents/GitHub/provenance-eco-rag')
sys.path.insert(0,str(ROOT))
os.environ.update(DEPLOYMENT_ENV='test',AUTH_MODE='disabled')
for name in ('CATALOGUE','INVESTIGATIONS','RESEARCH_CONTROLLER','RESEARCH_RUNS','RESEARCH_DISPATCH','EVIDENCE','SYNTHESIS','EXPERIMENTS','EXPERIMENT_DISPATCH','EXPERIMENT_WORKSPACE'):
    os.environ['ENABLE_V1_'+name]='true'
from sqlalchemy import create_engine,event
from db.app_models import AppBase
from tests.system_acceptance_support import make_system_acceptance_fixture,seed_integrated_browser,source_revision
with TemporaryDirectory(prefix='ocean-c26-mixed-profiler-') as directory:
    directory=Path(directory)
    engine=create_engine('sqlite+pysqlite:///'+str(directory/'app.sqlite'))
    @event.listens_for(engine,'connect')
    def keys(connection,_):
        connection.execute('PRAGMA foreign_keys=ON')
    AppBase.metadata.create_all(engine)
    fixture=make_system_acceptance_fixture(engine,directory)
    seed=seed_integrated_browser(fixture)
    context=seed['context']
    for reference in (seed['receipts'][0]['attachment_reference'],seed['execution']['artifacts'][0]['attachment_reference']):
        result=fixture.retained.service.invoke('context/change',{'investigation_id':context['investigation']['id'],'expected_revision_id':context['context']['id'],'idempotency_key':str(uuid.uuid4()),'change':{'op':'attach','reference':reference}},fixture.user)
        context={**context,**result}
    _,run=fixture.finish_run(context)
    request={**fixture.runs.address(run),'input_version':1,'offset':0,'limit':100}
    revision,files=source_revision()
    started=time.monotonic()
    first=fixture.evidence.invoke('list',request,fixture.user)
    first_wall=time.monotonic()-started
    profiler=cProfile.Profile()
    started=time.monotonic()
    profiler.enable()
    second=fixture.evidence.invoke('list',request,fixture.user)
    profiler.disable()
    second_wall=time.monotonic()-started
    profiler.dump_stats('/private/tmp/ocean-c26-mixed-evidence-profile-final-20261030.pstats')
    stats=pstats.Stats(profiler)
    rows=[]
    for (filename,line,function),(primitive,total,self_time,cumulative,callers) in stats.stats.items():
        if filename.startswith(str(ROOT)):
            rows.append({'path':str(Path(filename).relative_to(ROOT)),'line':line,'function':function,'primitive_calls':primitive,'total_calls':total,'self_seconds':self_time,'cumulative_seconds':cumulative})
    rows.sort(key=lambda row:row['cumulative_seconds'],reverse=True)
    after,afterfiles=source_revision()
    capture={'version':'c26-mixed-evidence-profile-v1','classification':'synthetic-local-actual-services','source_revision':revision,'source_files':files,'source_unchanged':revision==after and files==afterfiles,'first_unprofiled_wall_seconds':first_wall,'second_profiled_wall_seconds':second_wall,'response_equal':first==second,'receipts':len(second['items']),'response_sha256':hashlib.sha256(json.dumps(second,sort_keys=True).encode()).hexdigest(),'profile_rows':rows[:120]}
    with Path('/private/tmp/ocean-c26-mixed-evidence-profile-final-20261030.json').open('x') as stream:
        json.dump(capture,stream,indent=2)
    print(json.dumps({key:value for key,value in capture.items() if key not in ('source_files','profile_rows')}))
    print(json.dumps(rows[:35],indent=2))
    engine.dispose()
